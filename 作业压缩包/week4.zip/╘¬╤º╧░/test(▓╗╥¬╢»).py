import os
import torch
import numpy as np
import torch.nn as nn
from PIL import Image
import torch.nn.functional as F
from tensorflow.python.autograph.converters.control_flow import transform
from torchvision import transforms

global device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

#模型类，懒得引用了
class MAMLcnn(nn.Module):
    def __init__(self, in_ch=3, n_way=1000, chs=[64, 64, 64, 64], img_size=84):
        super().__init__()
        # 卷积层
        self.conv1 = nn.Conv2d(in_ch, chs[0], 3, padding=1)
        self.bn1 = nn.BatchNorm2d(chs[0])
        self.conv2 = nn.Conv2d(chs[0], chs[1], 3, padding=1)
        self.bn2 = nn.BatchNorm2d(chs[1])
        self.conv3 = nn.Conv2d(chs[1], chs[2], 3, padding=1)
        self.bn3 = nn.BatchNorm2d(chs[2])
        self.conv4 = nn.Conv2d(chs[2], chs[3], 3, padding=1)
        self.bn4 = nn.BatchNorm2d(chs[3])
        self.pool = nn.MaxPool2d(2)

        # 动态计算全连接层
        with torch.no_grad():
            dummy = torch.randn(1, in_ch, img_size, img_size)
            x = self.pool(F.relu(self.bn1(self.conv1(dummy))))
            x = self.pool(F.relu(self.bn2(self.conv2(x))))
            x = self.pool(F.relu(self.bn3(self.conv3(x))))
            x = self.pool(F.relu(self.bn4(self.conv4(x))))
            self.fc_in = x.view(1, -1).size(1)

        self.fc = nn.Linear(self.fc_in, n_way)

    def forward(self, x, params=None):
        """ 支持快速权重参数传递 """

        def get_param(key):
            return params[key] if params else getattr(self, key)

        def bn_pass(x, bn_name):
            return F.batch_norm(
                x,
                weight=get_param(f"{bn_name}.weight"),
                bias=get_param(f"{bn_name}.bias"),
                running_mean=None,  # 关键修复：禁用running_mean梯度
                running_var=None,  # 关键修复：禁用running_var梯度
                training=True  # 使用当前batch统计量
            )

        # 卷积部分
        x = F.conv2d(x, get_param('conv1.weight'), get_param('conv1.bias'), padding=1)
        x = bn_pass(x, 'bn1')  # 使用封装的BN处理
        x = F.relu(self.pool(x))

        x = F.conv2d(x, get_param('conv2.weight'), get_param('conv2.bias'), padding=1)
        x = bn_pass(x, 'bn2')
        x = F.relu(self.pool(x))

        x = F.conv2d(x, get_param('conv3.weight'), get_param('conv3.bias'), padding=1)
        x = bn_pass(x, 'bn3')
        x = F.relu(self.pool(x))

        x = F.conv2d(x, get_param('conv4.weight'), get_param('conv4.bias'), padding=1)
        x = bn_pass(x, 'bn4')
        x = F.relu(self.pool(x))

        # 全连接部分
        x = x.view(x.size(0), -1)
        x = F.linear(x, get_param('fc.weight'), get_param('fc.bias'))
        return x

class get_pht():
    def __init__(self,img_size,model):
        self.labels = []
        self.features = []
        self.tf = transforms.Compose([
            transforms.Resize(img_size),
            transforms.CenterCrop(img_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        self.extractor = nn.Sequential(
            model.conv1,
            model.bn1,
            nn.ReLU(),
            model.pool,
            model.conv2,
            model.bn2,
            nn.ReLU(),
            model.pool,
            model.conv3,
            model.bn3,
            nn.ReLU(),
            model.pool,
            model.conv4,
            model.bn4,
            nn.ReLU(),
            model.pool,
            nn.Flatten()
        ).eval().to(device)

    def pht_loader(self,data_root = r"../../最终考核/最终考核/fewshot_data/test"):
        print("正在开始加载数据喵---")
        for pht_name in os.listdir(data_root):
            pht_path = os.path.join(data_root, pht_name)
            pht = Image.open(pht_path).convert("RGB")
            tensor = self.tf(pht).unsqueeze(0).to(device)

            with torch.no_grad():
                feature = self.extractor(tensor).cpu().numpy()[0]
            self.features.append(feature)
            self.labels.append(int(pht_name.split("_")[0]))
            print("label", self.labels[-1], "name", pht_name)

    def __len__(self):
        return len(self.labels)
    def __getitem__(self,inx):
        feature = torch.tensor(self.features[inx], dtype=torch.float32).to(device)
        # 将标签转换为int64（Long）类型
        label = torch.tensor(self.labels[inx], dtype=torch.long).to(device)
        return feature, label,inx


if __name__ == "__main__":
    loader_mode_path = r"model.pth"
    model = MAMLcnn(
        n_way=5,  # 必须与训练时n_way相同
        img_size=84,
        chs=[64,128,256,512]
    ).to(device)
    state_dict = torch.load(loader_mode_path)
    model.load_state_dict(state_dict)
    print("模型加载正确")
    print("尝试加载数据----")
    phts = get_pht(img_size=84,model=model)
    phts.pht_loader()
    print("测试数据加载成功")
    correct = 0
    for feature,label_T,inx in phts:
        with torch.no_grad():
            output = model.fc(feature.unsqueeze(0))  # 添加batch维度
            _, pre_label = torch.max(output, 1)
            if pre_label == label_T:
                correct+=1
        print(f"样本 {inx + 1}:")
        print(f"  真实标签: {label_T}")
        print(f"  预测标签: {pre_label}")
        print(f"  是否正确: {'✅' if pre_label == label_T else '❌'}")

    accuracy = correct / len(phts)
    print(f"\n🎯 最终测试准确率: {accuracy:.2%}")
