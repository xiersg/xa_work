import os
import random
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image

# 设备配置
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


#数据集类
class FewShotDataset(Dataset):
    def __init__(self, root, n_way=5, k_shot=1, query_num=7, img_size=84):
        self.root = root
        self.n_way = n_way
        self.k_shot = k_shot
        self.query_num = query_num
        self.classes = [d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))]

        self.transform = transforms.Compose([
            transforms.Resize(img_size),
            transforms.CenterCrop(img_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])

    def generate_task(self):
        """ 生成支持集和查询集 """
        selected = random.sample(self.classes, self.n_way)
        support_x, support_y = [], []
        query_x, query_y = [], []

        for cls_id, cls in enumerate(selected):
            cls_dir = os.path.join(self.root, cls)
            imgs = [os.path.join(cls_dir, f) for f in os.listdir(cls_dir) if f.endswith(('.jpg', '.png'))]
            sampled = random.sample(imgs, 8)  # 每个类固定使用8个样本

            # 支持集
            for p in sampled[:self.k_shot]:
                img = Image.open(p).convert('RGB')
                support_x.append(self.transform(img))
                support_y.append(cls_id)

            # 查询集
            for p in sampled[self.k_shot:self.k_shot + self.query_num]:
                img = Image.open(p).convert('RGB')
                query_x.append(self.transform(img))
                query_y.append(cls_id)

        return (
            torch.stack(support_x),
            torch.tensor(support_y),
            torch.stack(query_x),
            torch.tensor(query_y)
        )


# ------------------ MAML模型类
class Cnn(nn.Module):
    def __init__(self, in_ch=3, n_way=5, chs=[64, 64, 64, 64], img_size=84):
        super().__init__()
        # 卷积层
        self.conv1 = nn.Conv2d(in_ch, chs[0], 3, padding=1)
        self.bn1 = nn.BatchNorm2d(chs[0])
        self.conv2 = nn.Conv2d(chs[0], chs[1], 3, padding=1)
        self.bn2 = nn.BatchNorm2d(chs[1])
        self.conv3 = nn.Conv2d(chs[1], chs[2], 3, padding=1)
        self.bn3 = nn.BatchNorm2d(chs[2])
        self.conv4 = nn.Conv2d(chs[2], chs[3], 3, padding=1)
        self.bn4 = nn.BatchNorm2d(chs[3])
        self.pool = nn.MaxPool2d(2)

        # 动态计算全连接层
        with torch.no_grad():
            dummy = torch.randn(1, in_ch, img_size, img_size)
            x = self.pool(F.relu(self.bn1(self.conv1(dummy))))
            x = self.pool(F.relu(self.bn2(self.conv2(x))))
            x = self.pool(F.relu(self.bn3(self.conv3(x))))
            x = self.pool(F.relu(self.bn4(self.conv4(x))))
            self.fc_in = x.view(1, -1).size(1)

        self.fc = nn.Linear(self.fc_in, n_way)

    def forward(self, x, params=None):
        def get_param(key):
            return params[key] if params else getattr(self, key)

        def bn_pass(x, bn_name):
            return F.batch_norm(
                x,
                weight=get_param(f"{bn_name}.weight"),
                bias=get_param(f"{bn_name}.bias"),
                running_mean=None,  # 关键修复：禁用running_mean梯度
                running_var=None,  # 关键修复：禁用running_var梯度
                training=True  # 使用当前batch统计量
            )

        # 卷积部分
        x = F.conv2d(x, get_param('conv1.weight'), get_param('conv1.bias'), padding=1)
        x = bn_pass(x, 'bn1')
        x = F.relu(self.pool(x))
        x = F.conv2d(x, get_param('conv2.weight'), get_param('conv2.bias'), padding=1)
        x = bn_pass(x, 'bn2')
        x = F.relu(self.pool(x))

        x = F.conv2d(x, get_param('conv3.weight'), get_param('conv3.bias'), padding=1)
        x = bn_pass(x, 'bn3')
        x = F.relu(self.pool(x))
        x = F.conv2d(x, get_param('conv4.weight'), get_param('conv4.bias'), padding=1)
        x = bn_pass(x, 'bn4')
        x = F.relu(self.pool(x))

        # 全连接部分
        x = x.view(x.size(0), -1)
        x = F.linear(x, get_param('fc.weight'), get_param('fc.bias'))
        return x

#训练
class train_m:
    def __init__(self, model, dataset, save_path):
        self.model = model.to(device)
        self.dataset = dataset
        self.optim = torch.optim.Adam(model.parameters(), lr=1e-3)
        self.save_path = save_path
        os.makedirs(save_path, exist_ok=True)
        assert (dataset.k_shot + dataset.query_num) <= 8, "样本数超限!"

    def train(self, epochs=100, tasks_per_epoch=100, inner_lr=0.01):
        for epoch in range(epochs):
            total_loss = 0.0
            self.model.train()

            for _ in range(tasks_per_epoch):
                # 生成任务
                s_x, s_y, q_x, q_y = self.dataset.generate_task()
                s_x, s_y = s_x.to(device), s_y.to(device)
                q_x, q_y = q_x.to(device), q_y.to(device)

                # 克隆初始参数
                fast_weights = {n: p.clone() for n, p in self.model.named_parameters()}

                # 内循环（支持集适应）
                pred = self.model(s_x, fast_weights)
                loss = F.cross_entropy(pred, s_y)
                grads = torch.autograd.grad(loss, fast_weights.values(), create_graph=True)
                fast_weights = {n: p - inner_lr * g for (n, p), g in zip(fast_weights.items(), grads)}

                # 外循环（查询集评估）
                q_pred = self.model(q_x, fast_weights)
                q_loss = F.cross_entropy(q_pred, q_y)
                total_loss += q_loss.item()

                # 元梯度更新
                self.optim.zero_grad()
                q_loss.backward()
                self.optim.step()

            # 打印训练信息
            avg_loss = total_loss / tasks_per_epoch
            print(f"Epoch {epoch + 1}/{epochs} | Loss: {avg_loss:.4f}")

            # 保存模型
            if (epoch + 1) % 10 == 0:
                torch.save(self.model.state_dict(), f"{self.save_path}/epoch_{epoch + 1}.pth")


# ------------------ 主程序    ------------------
if __name__ == "__main__":
    # 参数配置
    config = {
        "n_way": 5,
        "k_shot": 5,
        "query_num": 3,
        "img_size": 84,
        "epochs": 500,
        "tasks_per_epoch": 100
    }

    # 初始化组件
    dataset = FewShotDataset(
        root="../../最终考核/最终考核/fewshot_data/train",
        n_way=config["n_way"],
        k_shot=config["k_shot"],
        query_num=config["query_num"],
        img_size=config["img_size"]
    )

    model = Cnn(n_way=config["n_way"], img_size=config["img_size"],chs=[64,128,256,512])
    trainer = train_m(model, dataset, save_path="./saved_models_old")

    # 开始训练
    trainer.train(
        epochs=config["epochs"],
        tasks_per_epoch=config["tasks_per_epoch"]
    )
    print("训练完成！模型已保存至 ./saved_models")