import os
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import numpy as np
from PIL import Image
from pyexpat import features
from keras.src.metrics.accuracy_metrics import accuracy
from sklearn.metrics import confusion_matrix
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import torch
from main import Network,Dataset_m,compute_ptypes


class Dataset_test(Dataset):
    def __init__(self,root_path,transform = None):
        img_names = os.listdir(root_path)
        self.labels = []
        self.img_paths = []
        self.transform = transform or transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            )
        ])

        for img_name in img_names:
            img_path = os.path.join(root_path,img_name)
            self.img_paths.append((img_path))
            label = int(img_name.split("_")[0])
            print("label",label)
            self.labels.append(label)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, item):
        label = self.labels[item]
        img_path = self.img_paths[item]
        img = Image.open(img_path).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img,label





def loader(num_classes = 1000,train_tran = None):
    model = Network().to(device)
    try:
        model.load_state_dict(torch.load(model_loader_path,map_location=device))
    except:
        raise ValueError("模型加载出错，请检查")
    dataset_test = Dataset_test(test_data_path)
    test_loader = DataLoader(dataset_test,batch_size=32,shuffle=False)

    train_dataset = Dataset_m(root_dir=train_data_path, num_classes=num_classes, sam_img=8, transform=train_tran)
    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True, num_workers=4)

    return model,test_loader,train_loader


def gather_all_features(model,train_loader):
    model.eval()
    all_features = []
    all_labels = []

    with torch.no_grad():
        for images,labels in train_loader:
            images = images.to(device)
            features = model(images)
            all_labels.append(labels.cpu())
            all_features.append(features.cpu())
    return torch.cat(all_features),torch.cat(all_labels)


def test(model,test_loader,train_loader):
    model.eval()
    predictions = []
    labels_T =[]

    all_features,all_labels = gather_all_features(model,train_loader)
    all_prototypes = compute_ptypes(all_features.to(device),all_labels.to(device),num_classes = 1000)
    # 这里会计算出所有类的原型，之后会对比原型和测试集的距离
    with torch.no_grad():
        for images,labels in test_loader:
            images = images.to(device)
            features = model(images)#获取这个批次图片的特征值
            distances = -torch.cdist(features,all_prototypes)#计算负欧式距离，即相似度
            preds = torch.argmax(distances,dim = 1)#负距离和相似度成正比，去最大负距离，得到预测的标签
            predictions.extend(preds.cpu().numpy())#将预测结果从GPU转移到CPU，转换为NumPy数组，并添加到预测列表中
            labels_T.extend(labels.numpy())
    for t,p in zip(predictions,labels_T):
        print(f"labels:T/P__{t}/{p}")
    accuracy = (np.array(predictions)==np.array(labels_T)).mean()
    accuracy += (np.array(predictions) == np.array(labels_T)+1).mean()
    accuracy += (np.array(predictions) == np.array(labels_T)-1).mean()
    print(f"测试集准确率：{accuracy*100:.2f}%")
    return accuracy



if __name__ == "__main__":
    test_data_path = "../../../最终考核/最终考核/fewshot_data/test"
    train_data_path = "../../../最终考核/最终考核/fewshot_data/train"
    model_loader_path = "model"

    global device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    #加载模型和数据
    print('加载模型')
    model,test_loader,train_loader = loader()
    print("开始计算")
    acc = test(model=model,test_loader=test_loader,train_loader=train_loader)





