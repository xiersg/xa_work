import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image


class ResidualBlock(nn.Module):
    """残差块（带通道注意力）"""

    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)

        #从这里引入通道注意力
        self.ca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(out_channels, out_channels // 16, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(out_channels // 16, out_channels, kernel_size=1),
            nn.Sigmoid()
        )

        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels)
            )

    def forward(self, x):
        residual = self.shortcut(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = nn.ReLU()(out)
        out = self.conv2(out)
        out = self.bn2(out)

        #引入通道注意力权重
        ca_weight = self.ca(out)
        out = out * ca_weight

        out += residual
        return nn.ReLU()(out)


#定义空间注意力
class kj_Atte(nn.Module):
    """空间自注意力模块"""

    def __init__(self, in_dim):
        super().__init__()
        self.query = nn.Conv2d(in_dim, in_dim // 8, kernel_size=1)
        self.key = nn.Conv2d(in_dim, in_dim // 8, kernel_size=1)
        self.value = nn.Conv2d(in_dim, in_dim, kernel_size=1)
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        batch_size, C, H, W = x.size()

        # 生成Q,K,V
        q = self.query(x).view(batch_size, -1, H * W).permute(0, 2, 1)  # [B, HW, C']
        k = self.key(x).view(batch_size, -1, H * W)  # [B, C', HW]
        v = self.value(x).view(batch_size, -1, H * W)  # [B, C, HW]

        # 计算注意力权重
        attn = torch.bmm(q, k)  # [B, HW, HW]
        attn = torch.softmax(attn, dim=-1)

        # 加权融合
        out = torch.bmm(v, attn.permute(0, 2, 1))  # [B, C, HW]
        out = out.view(batch_size, C, H, W)

        return self.gamma * out + x


class Model(nn.Module):
    def __init__(self):
        super().__init__()
        # 初始卷积层
        self.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU()
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        # 残差阶段
        self.layer1 = self.make_layer(64, 128, 2, stride=1)
        self.layer2 = self.make_layer(128, 256, 2, stride=2)
        self.layer3 = self.make_layer(256, 512, 2, stride=2)

        # 自注意力模块
        self.attn = kj_Atte(512)

        # 自适应池化 + 全连接
        self.avgpool = nn.AdaptiveAvgPool2d(1)#自适应池化，直接压缩为1
        """虽然是丢失了空间信息，但是，保留了语义信息就足够了"""
        self.fc = nn.Linear(512, 1000)

        # 初始化权重
        self.init_w()

    def make_layer(self, in_channels, out_channels, blocks, stride):#快速创建多个重复层，用于残差网络
        layers = []
        layers.append(ResidualBlock(in_channels, out_channels, stride))
        for _ in range(1, blocks):
            layers.append(ResidualBlock(out_channels, out_channels))
        return nn.Sequential(*layers)

    def init_w(self):#这里进行权重的初始化
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)

        x = self.attn(x)  # 空间注意力增强
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)

        return x

class Dataset_m(Dataset):
    def __init__(self, root_dir, num_classes=1000, sam_img=7, transform=None,ms = "train"):
        super().__init__()
        self.root_dir = root_dir
        self.transform = transform or transforms.Compose([#数据预处理
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(0.4, 0.4, 0.4),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        self.classes = sorted(os.listdir(root_dir))[:num_classes]  # 确保类别顺序固定
        self.img_paths = []
        self.labels = []
        self.img_paths_val = []
        self.labels_val = []
        self.ms = ms
        if self.ms == "val":#顺便把val一起写了
            self.val_transform = transforms.Compose([
                transforms.Resize(256),
                transforms.CenterCrop(224),  # 固定中心裁剪
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                ])

        #按文件夹顺序分配标签
        for class_name in self.classes:
            label_idx = int(class_name)
            class_dir = os.path.join(root_dir, class_name)
            images = sorted(os.listdir(class_dir))[:sam_img]
            images_val = sorted(os.listdir(class_dir))[sam_img:]
            for img in images:
                self.img_paths.append(os.path.join(class_dir, img))  # 修正路径拼接
                self.labels.append(label_idx)  # 直接使用文件夹顺序作为标签
            for img in images_val:
                self.img_paths_val.append(os.path.join(class_dir,img))
                self.labels_val.append(label_idx)

    def __len__(self):
        if self.ms =="train":
            return len(self.img_paths)
        elif self.ms == "val":
            return len(self.labels_val)

    def __getitem__(self, idx):
        if self.ms == "train":
            img_path = self.img_paths[idx]
            image = Image.open(img_path).convert("RGB")
            label = self.labels[idx]
            if self.transform:
                image = self.transform(image)
            return image, label
        elif self.ms == "val":
            img_path = self.img_paths_val[idx]
            image = Image.open(img_path).convert("RGB")
            label = self.labels_val[idx]
            image = self.val_transform(image)
            return image, label


class Network(nn.Module):#模型类
    def __init__(self):
        super().__init__()
        self.backbone = Model()

        # 冻结前80%的层（按参数名匹配）
        for name, param in self.backbone.named_parameters():
            if 'conv1' in name or 'layer1' in name:
                param.requires_grad = False

    def forward(self, x):
        features = self.backbone(x)  # [batch_size, 1280]
        features = nn.functional.normalize(features, p=2, dim=1)  # L2归一化
        return features

    def save_model(self, path, epoch):
        # 自动创建目录
        os.makedirs(path, exist_ok=True)
        torch.save(self.state_dict(), os.path.join(path, f"model_{epoch}"))
        print("模型保存成功")

#根据输入的一批样本特征和对应标签，计算每个类别的原型向量（类内特征的平均值）。
def compute_ptypes(features, labels, num_classes=None):
    """支持单批次和全局原型计算"""
    if num_classes is None:
        unique_labels = torch.unique(labels)
        prototypes = []
        for lbl in unique_labels:
            mask = (labels == lbl)
            prototypes.append(features[mask].mean(dim=0))
        return torch.stack(prototypes), unique_labels
    else:
        prototypes = torch.zeros(num_classes, features.size(1))
        for class_idx in range(num_classes):
            mask = (labels == class_idx)
            if mask.any():
                prototypes[class_idx] = features[mask].mean(dim=0)
        return prototypes


def compute_ptypes_all(model, train_loader, num_classes=1000):#计算全部的原型
    model.eval()
    all_features = []
    all_labels = []

    with torch.no_grad():
        for images, labels in train_loader:
            features = model(images.to(device))
            all_features.append(features.cpu())
            all_labels.append(labels.cpu())

    all_features = torch.cat(all_features)
    all_labels = torch.cat(all_labels)

    prototypes = torch.zeros(num_classes, all_features.size(1)).to(device)
    for class_idx in range(num_classes):
        mask = (all_labels == class_idx)
        if mask.any():
            prototypes[class_idx] = all_features[mask].mean(dim=0)
    return prototypes


class PrototypeLoss(nn.Module):
    def __init__(self, temperature=0.1):
        super().__init__()
        self.temperature = temperature

    def forward(self, query_features, prototypes, proto_labels, query_labels):
        # 计算负余弦相似度（因特征已归一化，等价于负欧氏距离）
        similarity = torch.mm(query_features, prototypes.t())  # [batch, num_proto]
        similarity /= self.temperature

        # 创建标签映射（query_label -> proto_label索引）
        label_map = {lbl.item(): idx for idx, lbl in enumerate(proto_labels)}
        mapped_labels = torch.tensor([label_map[lbl.item()] for lbl in query_labels],
                                     device=query_features.device)

        return nn.CrossEntropyLoss()(similarity, mapped_labels)


def train_protonet(data_dir, train_tran,val_tran,num_classes=1000, num_epochs=100):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 数据加载
    train_dataset = Dataset_m(root_dir=data_dir, num_classes=num_classes, sam_img=7,transform=train_tran)
    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True, num_workers=4)
    val_dataset = Dataset_m(root_dir=data_dir, num_classes=num_classes, sam_img=1, transform=train_tran,ms="val")
    val_loader = DataLoader(val_dataset, batch_size=64, shuffle=True, num_workers=4)

    # 模型初始化
    model = Network().to(device)
    try:
        model.load_state_dict(torch.load(model_load_path, map_location=device))
        model.eval()
        print("模型继承成功")
    except:
        print("模型继承失败，初始化模型")

    #------------------------
    dummy_input = torch.randn(1, 3, 224, 224).to(device)
    features = model(dummy_input)
    print("特征示例:", features[0, :5],"输出结果应有非零值")  # 应有非零值
    #------------------------

    #优化器选择adam
    optimizer = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4)
    criterion = PrototypeLoss(temperature=0.1)

    # 训练循环
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0.0

        for images, labels in train_loader:
            images = images.to(device)
            labels = labels.to(device)
            #特征提取
            features = model(images)
            #计算当前原型
            prototypes, proto_labels = compute_ptypes(features, labels)
            #查询集
            query_transform = transforms.Compose([
                transforms.RandomResizedCrop(224, scale=(0.8, 1.0)),
                transforms.RandomRotation(30),
                transforms.ColorJitter(0.3, 0.3, 0.3),
                transforms.RandomErasing(p=0.5),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ])
            query_images = torch.stack([
                query_transform(img)
                for img in images
            ]).to(device)  # batch_img_paths是当前批次的图像路径
            query_features = model(query_images)#这里通过模型进行特征的提取，返回一个特征向量

            # 计算损失
            loss = criterion(query_features, prototypes, proto_labels, labels.to(device))
            #这里的原型和feature都是一个特征值，用来进行对比，不需要把query_features变成一个原型

            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)  # 梯度裁剪
            optimizer.step()#注意这反向传播的目的是进行相同原型和样本间的接近   不同原型和样本间的疏离

            total_loss += loss.item() * images.size(0)#计算总损失，用于观察进度

        # 打印训练信息
        avg_loss = total_loss / len(train_dataset)
        print(f"Epoch--{epoch + 1}/{num_epochs}, Loss---{avg_loss:.4f}")

        # 验证（示例，需自定义验证逻辑）
        all_prototypes = compute_ptypes_all(model, train_loader, num_classes=1000)
        if epoch % 1 == 0:
            val_fc(model,val_loader,all_prototypes,device)

        if epoch%5 == 0:
            model.save_model("save_model",epoch)


# 示例验证函数
def val_fc(model, val_loader, all_prototypes, device):
    model.eval()
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels in val_loader:
            images = images.to(device)
            labels = labels.to(device)

            # 提取验证集特征
            features = model(images)

            # 计算与所有训练原型的相似度
            similarity = torch.mm(features, all_prototypes.t())
            preds = torch.argmax(similarity, dim=1)

            correct += (preds == labels).sum().item()
            total += labels.size(0)

    accuracy = 100.0 * correct / total
    print(f"验证准确率: {accuracy:.2f}%")
    return accuracy

if __name__ == "__main__":
    global device,model_load_path
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model_load_path = r"model"

    num_epochs = 100
    train_data_path = "../../../最终考核/最终考核/fewshot_data/train"
    #test_data_path = "../../../最终考核/最终考核/fewshot_data/test"

    train_transform = transforms.Compose([
        transforms.RandomResizedCrop(224, scale=(0.6, 1.0)),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4),
        transforms.RandomGrayscale(p=0.2),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])
    """    val_transform = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),  # 固定中心裁剪
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])"""

    train_protonet(train_data_path,train_transform,None)
    print("工程可能还未毕(哭晕在厕所)")

