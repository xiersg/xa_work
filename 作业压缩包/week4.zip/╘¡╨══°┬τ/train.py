import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import transforms, models
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os

class Dataset_m(Dataset):
    def __init__(self,root_dir,num_classes=1000,sam_img = 8,transform = None):
        self.root_dir = root_dir
        self.transform = transform if transform!=None else transforms.Compose([
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        self.classes = os.listdir(root_dir)[:num_classes]
        self.img_paths = []
        self.labels = []

        for class_name in self.classes:
            try:
                class_label = int(class_name)
            except:
                continue
            class_path = os.path.join(self.root_dir,class_name)
            for img_name in os.listdir(class_path)[:sam_img]:
                self.img_paths.append(os.path.join(class_path,img_name))
                self.labels.append(class_label)


    def __len__(self):
        return len(self.labels)

    def __getitem__(self, item):
        img_path = self.img_paths[item]
        image = Image.open(img_path).convert("RGB")
        label = self.labels[item]
        try:
            image = self.transform(image)
        except:
            print("未定义图像预处理")
        return image,label

class PrototypicalNetwork(nn.Module):
    def __init__(self,feature_dim=1280):
        super().__init__()
        # 使用预训练的EfficientNet-B0作为特征提取器
        self.backbone = models.efficientnet_b0(pretrained=True)
        self.backbone.classifier = nn.Identity()  # 移除原始分类头

        # 冻结所有层（初始阶段）
        for param in self.backbone.parameters():
            param.requires_grad_(False)

        # 可微调最后3个块（可选）
        self.unfreeze_layers = [self.backbone.features[5],
                                self.backbone.features[6],
                                self.backbone.features[7]]
        for layer in self.unfreeze_layers:
            for param in layer.parameters():
                param.requires_grad_(True)

    def forward(self, x):
        features = self.backbone(x)  # [batch_size, 1280]
        return features

def computr_prototypes(features,labels,num_classes = 1000):
    """
        输入:
            features: [batch_size, feature_dim]
            labels: [batch_size]
        输出:
            prototypes: [num_classes, feature_dim]
        """
    prototypes = torch.zeros(num_classes,features.size(1).to(features.device))
    for class_idx in range(num_classes):
        mask = (labels == class_idx)
        if mask.sum()>0:#防止空类
            prototypes[class_idx] = features[mask].mean(dim=0)
    return prototypes

def prototype_loss(query_features, prototypes, query_labels, temperature=1.0):
    """
    计算基于原型的交叉熵损失
    """
    # 计算负欧氏距离（相似度）
    distances = -torch.cdist(query_features, prototypes, p=2)  # [batch_size, num_classes]
    # 温度缩放（可调节类间距离的锐化程度）
    logits = distances / temperature
    return nn.CrossEntropyLoss()(logits, query_labels)

class train():
    def __init__(self,model):
        self.num_epochs = 100
        self.train_data_path = "../../../最终考核/最终考核/fewshot_data/train"
        self.test_data_path = "../../../最终考核/最终考核/fewshot_data/test"
        self.model = model
        self.optim = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4)

    def forward(self):
        dataset_m = Dataset_m(self.train_data_path)
        train_loader = DataLoader(
            dataset_m,
            batch_size=8,  # 每个批次包含1个类别的8个样本
            shuffle=True,
            num_workers=4
        )

        for epoch in range(self.num_epochs):
            model.train()
            total_loss = 0.0

            for imges,labels in train_loader:





if __name__ == "__main__":
    global device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = PrototypicalNetwork().to(device)
    train_n = train(model)

