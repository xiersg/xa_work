import torch.nn as nn
from torchvision import models
import torch

class ConditionalLayer(nn.Module):
    def __init__(self,input_dim,parent_dim,num_classes):
        super().__init__()
        self.fc = nn.Linear(input_dim,parent_dim,num_classes)
    def forward(self,x,parent_probs):
        fea_com = torch.cat([x,parent_probs],dim=1)
        return self.fc(fea_com)

class HierarchicalModel(nn.Module):
    def __init__(self, hierarchy_depths = [20,100,500,1000]):
        super().__init__()
        # 共享特征提取器
        self.feature_extractor = nn.Sequential(
            *list(models.resnet50(pretrained=True).children())[:-1])

        # 动态创建分类头
        self.transition_layers = nn.ModuleList([
            nn.Linear(parent_dim, child_dim, bias=False)  # 可学习权重矩阵
            for parent_dim, child_dim
            in zip(hierarchy_depths[:-1], hierarchy_depths[1:])
        ])

        self.classifiers = nn.ModuleList([
            nn.Linear(2048, depth) for depth in hierarchy_depths
        ])

    def forward(self, x):
        features = self.feature_extractor(x).squeeze()
        outputs = []
        for layer_idx, cls in enumerate(self.classifiers):
            layer_output = cls(features)
            if layer_idx > 0:
                parent_contribution = self.transition_layers[layer_idx - 1](outputs[layer_idx - 1])
                layer_output += parent_contribution  # 可学习权重已包含在矩阵中

            outputs.append(layer_output)

        return outputs

    def get_transition_matrix(self, layer_index):
        """获取指定层级的可学习转移矩阵"""
        return self.transition_layers[layer_index].weight.data.T

    def save(self, path):
        torch.save({
            'model_state': self.state_dict(),
            'hierarchy_depths': [cls.out_features for cls in self.classifiers]
        }, path)

    @classmethod
    def load(cls, path):
        checkpoint = torch.load(path)
        model = cls(checkpoint['hierarchy_depths'])
        model.load_state_dict(checkpoint['model_state'])
        return model