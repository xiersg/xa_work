import torch
from keras.src.metrics.accuracy_metrics import accuracy
from torch.utils.data import DataLoader
from model_2 import HierarchicalModel
from utils.dataset import HierarchicalDataset
from utils.hierarchy import HierarchyLoader
from utils.config import Config
from torch.utils.data import Dataset,DataLoader
from torchvision import transforms
import torch.nn.functional as F
import os
from PIL import Image

class Dataset_m(Dataset):
    """你的原始数据集基类，与最初提供的代码一致"""

    def __init__(self, phs_path, transform=None):
        self.phs_path =phs_path
        self.transform = transform or self.default_transform()
        self.phs_names = sorted(os.listdir(self.phs_path))
        self.image_paths = []
        self.labels = []

        # 收集所有图像路径
        for phs_id, phs_name in enumerate(self.phs_names):
            phs = os.path.join(phs_path, phs_name)
            self.labels.append(phs_name.split('_')[0])
            self.image_paths.append((phs, phs_id))

    def default_transform(self):
        return transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path, class_id = self.image_paths[idx]
        img = Image.open(img_path).convert('RGB')
        label = int(self.labels[idx])
        if self.transform:
            img = self.transform(img)
        return img, torch.tensor(label)


def evaluate(model, test_loader, device, hierarchy):
    model.eval()
    acc_sum = 0
    total = 0
    layer3_dict,layer2_dict,layer1_dict = [hierarchy.hierarchy[f"layer{i}"]["child_to_parent"] for i in range(1,4)]

    with torch.no_grad():
        for images, labels in test_loader:
            images = images.to(device)
            outputs = model(images)  # 现在输出包含4个层级
            """
            outputs[1] += torch.tensor([outputs[0][layer1_dict[i]] for i in range(len(outputs[1]))])
            outputs[2] += torch.tensor([outputs[1][layer2_dict[i]]* 0.7 for i in range(len(outputs[2]))])
            outputs[3] += torch.tensor([outputs[2][layer3_dict[i]]* 0.7 for i in range(len(outputs[3]))])
            """
            """# 逐层验证
            for layer_idx in range(4):
                layer_name = f'layer{layer_idx}'
                logits = outputs[layer_idx]

                # 应用层级约束
                if layer_idx > 0:
                    # 获取父层预测的合法子类
                    parent_pred = torch.argmax(outputs[layer_idx - 1], dim=1)
                    valid_mask = torch.zeros_like(logits, dtype=torch.bool)
                    for i, pred in enumerate(parent_pred):
                        children = hierarchy.get_children(pred.item(), layer_idx - 1)
                        valid_mask[i, children] = True
                    logits[~valid_mask] = -float('inf')"""

            # 计算准确率
            probabilities = F.softmax(outputs[3], dim=0)  # ✅ 明确指定dim=1
            _, predicted = torch.max(probabilities, 0)  # ✅ 正确维度

            # 确保标签在相同设备
            labels = labels.to(predicted.device)

            print("index",total,"pre",predicted,"true",labels[0])
            acc_sum += 1 if labels == predicted else 0  # 直接累加正确数
            total+=1

    # 打印结果
    acc = 100 * acc_sum / total
    print(f"最终正确率 Accuracy: {acc:.4f}%")


def main(model_path):
    Config.setup()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 加载层级关系
    hierarchy = HierarchyLoader(Config.hierarchy_path)
    for i in range(1,4):
        layer_child_to_parent = hierarchy.hierarchy[f"layer{i}"]["child_to_parent"]
        keys = list(layer_child_to_parent.keys())
        print(f"layer{i},max_id={max(keys)},min_id={min(keys)}")

    # 加载模型
    model = HierarchicalModel.load(model_path).to(device)

    # 加载测试数据
    dataset_test = Dataset_m(Config.test_data_path)
    test_loader = DataLoader(dataset_test)
    """test_set = HierarchicalDataset(Config.test_data_path, hierarchy)
    test_loader = torch.utils.data.DataLoader(
        test_set, batch_size=Config.batch_size, shuffle=False)"""

    # 评估
    evaluate(model, test_loader, device, hierarchy)


if __name__ == "__main__":
    main(r"saved_models/model_epoch24.pth")