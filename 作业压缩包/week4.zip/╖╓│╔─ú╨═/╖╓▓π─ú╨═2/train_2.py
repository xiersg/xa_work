import torch
from torch import optim
from model_2 import HierarchicalModel as fc_model
from utils.dataset import HierarchicalDataset
from utils.hierarchy import HierarchyLoader
from utils.config import Config
import torch.nn as nn
import torch.nn.functional as F


def main():
    Config.setup()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 加载层级关系
    hierarchy = HierarchyLoader(Config.hierarchy_path)

    # 初始化模型
    try:
        model_loa = torch.load(loader_model_path)
        model = fc_model(model_loa['hierarchy_depths']).to(device)
        model.load_state_dict(model_loa['model_state'], strict=False)  # 允许部分加载
        print("部分加载成功，缺失参数将随机初始化")
    except Exception as e:
        print(f"加载失败: {str(e)}")
        model = fc_model([20, 100, 500, 1000]).to(device)

    # 数据加载
    train_set = HierarchicalDataset(Config.train_data_path, hierarchy)
    train_loader = torch.utils.data.DataLoader(
        train_set, batch_size=Config.batch_size, shuffle=True)

    # 优化器
    optimizer = optim.SGD(model.parameters(), lr=Config.lr, momentum=0.9)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=30, gamma=0.1)

    # 训练循环
    for epoch in range(Config.num_epochs):
        model.train()
        total_loss = 0.0

        for images, labels in train_loader:
            images = images.to(device)
            labels = {k: v.to(device) for k, v in labels.items()}

            # 前向传播
            outputs = model(images)  # outputs是列表，包含[layer0_logits, layer1_logits, ...]

            # 分层损失计算
            losses = []
            for layer_idx, layer_name in enumerate(["layer0", "layer1", "layer2", "layer3"]):
                # 获取当前层级的logits和真实标签
                logits = outputs[layer_idx]  # 形状: (batch_size, num_classes)
                true_labels = labels[layer_name]  # 形状: (batch_size,)

                # 计算交叉熵损失（自动处理softmax）
                loss_weight = 0.3 ** layer_idx  # 层级越深权重越小（示例）
                loss = F.cross_entropy(logits, true_labels) * loss_weight
                losses.append(loss)

            # 总损失
            total_batch_loss = sum(losses)

            # 反向传播
            optimizer.zero_grad()
            total_batch_loss.backward()
            optimizer.step()

            # 累积损失用于打印
            total_loss += total_batch_loss.item()

        # 学习率调整
        scheduler.step()

        # 打印平均损失
        avg_loss = total_loss / len(train_loader)
        print(f"Epoch [{epoch + 1}/{Config.num_epochs}] Loss: {avg_loss:.4f}")

        # 保存最佳模型
        if epoch % 2 == 0:
            model.save(f"{Config.save_dir}/model_epoch{epoch}.pth")
            print(f"Epoch {epoch+1} | Loss: {total_loss:.4f}")


if __name__ == "__main__":
    global loader_model_path
    loader_model_path = None
    main()