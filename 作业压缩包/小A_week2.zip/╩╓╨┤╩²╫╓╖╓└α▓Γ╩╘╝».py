import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from tensorflow.python.keras.metrics import accuracy
from torch.utils.data import DataLoader,Dataset,random_split
from torchvision import transforms
from PIL import Image
import os
import numpy as np
from 手写数字分类 import val_loader,test_loader,model


load_path_m = r"model"
torch.manual_seed(99)
lossion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)
epochs = 10

dict_model = torch.load(load_path_m)
model.load_state_dict(dict_model['model_state_dict'])
print("加载成功")


#把测试集的数据用来训练
model.train()
for i in range(epochs):
    total_loss = 0
    for img,labels in val_loader:
        val_out = model(img)
        loss = lossion(val_out,labels-22)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss+=loss
    print(f"loss = {total_loss}")

print("训练结束\n\n测试集测试模型")

model.eval()#评估模式开启
correct_test = 0
total_test = 0

with torch.no_grad():#关闭梯度计算，进行模型评估
    for img ,labels in test_loader:
        test_outputs = model(img)
        _,predicted = torch.max(test_outputs,1)
        total_test+=labels.size(0)
        correct_test += (predicted==labels-22).sum().item()


accur_test = 100*correct_test/total_test
print(f"测试集准确率：accuracy{accur_test}")