import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from tensorflow.python.keras.metrics import accuracy
from torch.utils.data import DataLoader,Dataset,random_split
from torchvision import transforms
from PIL import Image
import os
import numpy as np
from 天气分类 import model,test_loader


load_path_m = r"model2"
torch.manual_seed(909)

#定义损失函数和优化器
lossion = nn.CrossEntropyLoss()
optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)

#加载模型
dict_model = torch.load(load_path_m)
model.load_state_dict(dict_model['model_state_dict'])
print("加载成功")



print("测试集测试模型")
model.eval()#评估模式开启
correct_test = 0
total_test = 0

with torch.no_grad():#关闭梯度计算，进行模型评估
    for img ,labels in test_loader:
        test_outputs = model(img)
        _,predicted = torch.max(test_outputs,1)
        total_test+=labels.size(0)
        correct_test += (predicted==labels).sum().item()


accur_test = 100*correct_test/total_test
print(f"测试集准确率：accuracy{accur_test}")