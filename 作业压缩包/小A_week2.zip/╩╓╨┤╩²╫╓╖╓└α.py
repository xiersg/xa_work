import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from tensorflow.python.keras.metrics import accuracy
from torch.utils.data import DataLoader,Dataset,random_split
from torchvision import transforms
from PIL import Image
import os
import numpy as np

torch.manual_seed(65)
epochs = 20
load_path_m = r"model"
save_path_m = r"models"

#数据预处理
tf = transforms.Compose([
    transforms.Resize(28),
    transforms.CenterCrop(28),
    transforms.ToTensor(),
    transforms.Normalize((0.5),(0.5))
])


#Dataset类
class Dataset_my(Dataset):
    def __init__(self,tf,dir):
        self.tf = tf#标准化类
        self.dir = dir
        self.class_folders = sorted([d for d in os.listdir(dir) if os.path.isdir(os.path.join(dir, d))])#生成地址
        self.img_paths = []#图片地址列表
        self.labels = []#标签列表

        for folder in self.class_folders:
            folder_path = os.path.join(dir,folder)#进入文件夹
            label = int(folder)
            for img_name in os.listdir(folder_path):
                if img_name.endswith(".jpg"):#检测扩张名，其实可以不要的
                    self.img_paths.append(os.path.join(folder_path,img_name))#挨个循环获取所有图片地址
                    self.labels.append(label)

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self,idx):
        img_path = self.img_paths[idx]
        label = self.labels[idx]

        img = Image.open(img_path).convert("L")
        img = self.tf(img)
        label = torch.tensor(label,dtype = torch.long)
        return img,label

#划分数据集
dataset = Dataset_my(tf,r"../考核二/data1")
total_size = len(dataset)
train_dataset,val_dataset,test_dataset = random_split(
    dataset,
    [int(0.8*total_size),int(0.1*total_size),int(0.1*total_size)]
)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=32)
test_loader = DataLoader(test_dataset, batch_size=32)


# 定义模型
class CNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Conv2d(1, 32, kernel_size=3, stride=1, padding=1)
        self.fc2 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.fc3 = nn.Linear(64 * 7 * 7, 128)
        self.fc4 = nn.Linear(128, 10)

    def forward(self, x):
        x = F.relu(self.fc1(x))  # CNN+ReLU
        x = F.max_pool2d(x, 2)  # 池化层
        x = F.relu(self.fc2(x))
        x = F.max_pool2d(x, 2)
        # 压缩成一个向量，展平
        x = x.view(-1, 64 * 7 * 7)
        x = F.relu(self.fc3(x))

        return x


model = CNN()  # 实例化模型

if __name__ == "__main__":

    # 定义损失函数
    lossion = nn.CrossEntropyLoss()  # 交叉熵
    # 定义优化器
    optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.9)

    model.train()  # 请求开启训练模式


    # 准许

    # 定义模型保存函数
    def save_model(epoch, model, opt, path):
        dict_model = {
            "epoch": epoch,
            "model_state_dict": model.state_dict(),
            "opt_state_dict": opt.state_dict()
        }
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save(dict_model, path)
        print(f"模型保存,来自{epoch}")


    # 定义模型加载函数
    def loading_model(path, model, opt):
        if not os.path.exists(path):
            raise FileNotFoundError(f"模型文件不存在于{path}")

        dict_model = torch.load(path)
        # 加载模型参数
        model.load_state_dict(dict_model['model_state_dict'])
        # 加载优化器
        opt.load_state_dict(dict_model["opt_state_dict"])
        # 加载数据
        sta = dict_model["epoch"] + 1
        print(f"成功加载数据点，从epoch{sta}开始训练")
        return sta


    #加载模型
    try:
        sta = loading_model(
            path=load_path_m,
            model = model,
            opt=optimizer
        )
    except FileNotFoundError:
        print("尝试加载模型失败\n开始初始化模型")
        sta = 0


    #开始训练
    for i in range(sta,sta+epochs):
        total_loss = 0#总损失
        for img,label in train_loader:
            y_hat = model(img)
            #print(y_hat.shape,label.shape)
            loss = lossion(y_hat,label-22)
            #更行参数
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss+= loss

        print("epoch:",i,"  loss= ",total_loss.item())

        #关闭梯度计算，进行验证集正确率计算
        with torch.no_grad():
            total_val = 0
            correct_val = 0
            for img,labels in val_loader:
                val_out = model(img)
                _,predicted = torch.max(val_out,1)
                total_val+=labels.size(0)
                correct_val+=(predicted==labels-22).sum().item()

            accur_val = 100*correct_val/total_val
            print(f"验证集准确率为:{accur_val}")

        if i %10 == 0 and i != 0:
            save_model(i,model,optimizer,os.path.join(save_path_m,f"epoch_{i}_loss_{total_loss:.4f}_准确率_{accur_val}"))




