import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sympy.physics.units import momentum
from torchvision import transforms
from PIL import Image
from torch.utils.data import DataLoader,Dataset,random_split
import os
from transformers.pipelines.question_answering import Dataset
from class_func import Dataset_m,tf,model_class,model_loader_save
from torch.optim.lr_scheduler import ReduceLROnPlateau


def train(model,opt,x,val,sta,epochs,scheduler):
    model.train()
    print("开始训练")
    for i in range(sta,sta+epochs):

        total_loss = 0
        for img,label in x:

            img, label = img.to(device), label.to(device)
            y_hat = model(img)
            loss = lossion(y_hat,label)
            total_loss+=loss

            opt.zero_grad()
            loss.backward()
            opt.step()

        scheduler.step(total_loss/len(x))
        current_lr = opt.param_groups[0]['lr']
        print(f"epoch {i + 1} | 损失: {total_loss/len(x):.4f} | 学习率: {current_lr:.6f}")


        if i%5 == 0:
            dic = {
                "epoch" :i,
                "model_state_dict":model.state_dict(),
                "opt_state_dict":opt.state_dict(),
                "scheduler_state_dict":scheduler.state_dict()
            }
            path = os.path.join(save_path_model,f"epoch_{i}_loss_{total_loss/len(x):.4f}")
            model_loader_save.save_model(path,dic)
            print(f"模型保存成功,位于{path}")
            if val!=None:
                model.eval()  # 评估模式开启
                correct_test = 0
                total_test = 0
                with torch.no_grad():  # 关闭梯度计算，进行模型评估
                    for img, labels in val:
                        test_outputs = model(img)
                        _, predicted = torch.max(test_outputs, 1)
                        total_test += labels.size(0)
                        correct_test += (predicted == labels).sum().item()

                accur_test = 100 * correct_test / total_test
                print(f"训练集准确率：accuracy{accur_test}\n")




#----------------------------------------------------------------

loader_path_pht = r"../考核三_CV/考核三/butterflies-classification"
loader_path_train = os.path.join(loader_path_pht, "train_butterflies","train_split")
loader_path_test = os.path.join(loader_path_pht, "test_butterflies","valid")
save_path_model = "../models"
loader_path_model = "../model"
epochs = 2000
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = model_class(50).to(device)
# 定义损失函数和优化器
lossion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=1e-3, weight_decay=0.01)
scheduler = ReduceLROnPlateau(
    optimizer,
    mode='min',  # 越小越好
    factor=0.5,  # 学习率衰减因子（new_lr = lr * factor）
    patience=3,  # 等待 5 个 epoch 无改善后调整
    verbose=True  # 打印调整信息
)

dataset_m = Dataset_m(tf, loader_path_train, device)
train_data ,valdata = torch.utils.data.random_split(dataset_m,[int(0.8*len(dataset_m)+0.5),int(0.2*len(dataset_m)+0.5)])#弄一下四舍五入，免得报错
#dataloader_m = DataLoader(train_data,batch_size=64,shuffle=True)
dataloader_val = None
#dataloader_val = DataLoader(valdata,batch_size=64,shuffle=False)
dataloader_m = DataLoader(dataset_m, batch_size=64, shuffle=True)

#-------------------------------------------------------------------



if __name__ == "__main__":

    #加载模型数据
    sta = model_loader_save.loader_model(loader_path_model,model,optimizer,device)

    train(model,optimizer,dataloader_m,dataloader_val,sta,epochs,scheduler)