import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torchvision
import torch.optim as optim
from torch.xpu import device
from torchvision import transforms
from PIL import Image
from torch.utils.data import DataLoader,Dataset,random_split
import os
from transformers.pipelines.question_answering import Dataset
from torch.optim.lr_scheduler import ReduceLROnPlateau


from main import loader_path_train as loader_path

tf1 = transforms.Compose([
    transforms.RandomCrop(100),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.ColorJitter(
        brightness=0.2,    # 亮度抖动
        contrast=0.2,      # 对比度抖动
        saturation=0.2    # 饱和度抖动#
    )
])
tf2 = transforms.Compose([
    transforms.CenterCrop(75),
    transforms.RandomHorizontalFlip(p=0.5),
    transforms.ColorJitter(
        brightness=0.2,  # 亮度抖动
        contrast=0.2,  # 对比度抖动
        saturation=0.2  # 饱和度抖动#
    )
])

i = 15000
loader_path = os.path.join(loader_path)
print(loader_path)
for folder in loader_path:
    for class_name in os.listdir(os.path.join(loader_path,folder)):
        class_path = os.path.join(loader_path,folder,class_name)
        for img_name in os.listdir(class_path):
            img =  Image.open(os.path.join(class_path,img_name))
            if np.array(img).shape[0]<=100:
                break

            for tf in (tf1,tf1,tf1,tf2):
                img_new = tf(img)
                i += 1
                img_new.save(os.path.join(class_path,f"{i}.jpg"))
            print(f"{img_name}.....")
        print(f"{class_name}结束\n\n")



