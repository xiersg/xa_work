import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sympy.physics.units import momentum
from torchvision import transforms
from PIL import Image
from torch.utils.data import DataLoader,Dataset,random_split
import os
from transformers.pipelines.question_answering import Dataset
from class_func import tf,model_class,model_loader_save


class Dataset_m(Dataset):
    def __init__(self,tf,dir,device):
        self.tf = tf
        self.dir = dir#dir是train和test的目录
        self.img_paths = []
        self.device = device

        self.inx = []
        for img_name in os.listdir(dir):
            if img_name.endswith(".jpg"):
                self.inx.append(int("".join([l for l in img_name if l.isdigit()])))
                self.img_paths.append(os.path.join(dir,img_name))
        print(self.inx)

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, idx):
        img_path = self.img_paths[idx]
        img = Image.open(img_path).convert("L")
        img = self.tf(img)
        return img.to(self.device)


def test(loader_test,model,inx):
    print("测试集测试模型")
    model.eval()  # 评估模式开启
    pres = None

    with torch.no_grad():
        for img in loader_test:
            test_outputs = model(img)
            _,predicted = torch.max(test_outputs,1)
            if pres == None:
                pres = predicted
            else :
                pres = torch.cat([pres,predicted],dim = 0)

        pres = pres.unsqueeze(1)
        print(pres.shape)
        combined = torch.cat([inx, pres], dim=1)
        print(f"predicted{combined}")
        df = pd.DataFrame(combined.numpy(),columns=["index", "label"])
        df.to_csv("out2.csv",index = False)

if __name__ == "__main__":
    loader_path_pht = r"../考核三_CV/考核三/butterflies-classification"
    loader_path_test = os.path.join(loader_path_pht, "test_butterflies","valid")
    loader_path_model = "../model"
    global device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = model_class(50).to(device)
    dataset_m = Dataset_m(tf, loader_path_test, device)
    inx = torch.tensor([dataset_m.inx]).T
    print(inx.shape)
    dataloader_m = DataLoader(dataset_m, batch_size=64, shuffle=False)
    model.load_state_dict(torch.load(loader_path_model)["model_state_dict"])

    test(dataloader_m,model,inx)

